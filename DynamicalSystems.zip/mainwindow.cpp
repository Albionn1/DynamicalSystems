#include "mainwindow.h"
#include "helpdialog.h"
#include "initialconditionsdialog.h"
#include <QPainter>
#include <QKeyEvent>
#include <QFileDialog>
#include <QDateTime>
#include <QPixmap>
#include <QMessageBox>
#include <cmath>
#include <deque>
#include <QSvgRenderer>
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QScrollArea>

MainWindow::MainWindow(QWidget* parent) : QMainWindow(parent) {
    setWindowTitle("Dynamical Systems Visualizer");
    resize(1600, 900);

    setupUI();

    setSystem(1);
    resetState();

    // Simulation timer
    connect(&timer_, &QTimer::timeout, this, [this]{
        if (simulationActive_) {
            for (int i = 0; i < substeps_; ++i) step();
            canvasWidget_->update();
        }
    });
    timer_.start(16);

    // FPS timer
    connect(&fpsTimer_, &QTimer::timeout, this, [this]{
        updateFPS();
    });
    fpsTimer_.start(1000);

    // Start simulation by default
    simulationActive_ = true;
    simulationStarted_ = true;

    update();
}

void MainWindow::setupUI() {
    // Main central widget with 3-panel layout
    QWidget* mainWidget = new QWidget(this);
    QHBoxLayout* mainLayout = new QHBoxLayout(mainWidget);
    mainLayout->setContentsMargins(0, 0, 0, 0);
    mainLayout->setSpacing(0);
    setCentralWidget(mainWidget);

    // Create left panel
    createLeftPanel();
    mainLayout->addWidget(leftPanel_, 0);

    // Create canvas (center)
    canvasWidget_ = new QWidget(this);
    canvasWidget_->setStyleSheet("background-color: rgb(18, 18, 22);");
    canvasWidget_->setFocusPolicy(Qt::StrongFocus);
    mainLayout->addWidget(canvasWidget_, 1);

    // Create right panel
    createRightPanel();
    mainLayout->addWidget(rightPanel_, 0);
}

void MainWindow::createLeftPanel() {
    leftPanel_ = new QWidget(this);
    leftPanel_->setMaximumWidth(220);
    leftPanel_->setMinimumWidth(200);
    leftPanel_->setStyleSheet(
        "QWidget { background-color: rgb(35, 35, 45); color: #ecf0f1; }"
        "QLabel { color: #3498db; font-weight: bold; font-size: 11px; }"
        "QListWidget { background-color: rgb(45, 45, 55); border: none; }"
        "QListWidget::item { padding: 8px; color: #ecf0f1; }"
        "QListWidget::item:selected { background-color: rgb(52, 152, 219); }"
        "QGroupBox { color: #3498db; font-weight: bold; border: 1px solid rgb(60, 60, 70); border-radius: 4px; margin-top: 8px; padding-top: 8px; }"
        "QGroupBox::title { subcontrol-origin: margin; subcontrol-position: top left; padding: 0 3px; }"
        "QDoubleSpinBox { background-color: rgb(50, 50, 60); color: #ecf0f1; border: 1px solid rgb(70, 70, 80); padding: 2px; }"
        "QPushButton { background-color: rgb(52, 152, 219); color: white; border: none; padding: 6px; border-radius: 3px; font-weight: bold; }"
        "QPushButton:hover { background-color: rgb(41, 128, 185); }"
    );

    QVBoxLayout* layout = new QVBoxLayout(leftPanel_);
    layout->setContentsMargins(10, 10, 10, 10);
    layout->setSpacing(8);

    // SYSTEMS section
    QGroupBox* systemsGroup = new QGroupBox("SYSTEMS", leftPanel_);
    QVBoxLayout* systemsLayout = new QVBoxLayout(systemsGroup);
    systemsLayout->setContentsMargins(5, 15, 5, 5);
    systemsLayout->setSpacing(3);

    systemsList_ = new QListWidget(leftPanel_);
    systemsList_->addItem("1. Lorenz Attractor");
    systemsList_->addItem("2. Rössler System");
    systemsList_->addItem("3. Van der Pol Oscillator");
    systemsList_->addItem("4. Double Pendulum");
    systemsList_->setCurrentRow(0);
    systemsList_->setMaximumHeight(120);

    connect(systemsList_, &QListWidget::itemClicked, this, [this](QListWidgetItem* item) {
        int row = systemsList_->row(item);
        setSystem(row + 1);
        update();
    });

    systemsLayout->addWidget(systemsList_);
    layout->addWidget(systemsGroup);

    // INITIAL CONDITIONS section
    QGroupBox* icGroup = new QGroupBox("INITIAL CONDITIONS", leftPanel_);
    QVBoxLayout* icLayout = new QVBoxLayout(icGroup);
    icLayout->setContentsMargins(5, 15, 5, 5);
    icLayout->setSpacing(5);

    // Xp input
    QLabel* xpLabel = new QLabel("X₀", leftPanel_);
    xpInput_ = new QDoubleSpinBox(leftPanel_);
    xpInput_->setRange(-100.0, 100.0);
    xpInput_->setValue(0.1);
    xpInput_->setSingleStep(0.1);
    icLayout->addWidget(xpLabel);
    icLayout->addWidget(xpInput_);

    // Yp input
    QLabel* ypLabel = new QLabel("Y₀", leftPanel_);
    ypInput_ = new QDoubleSpinBox(leftPanel_);
    ypInput_->setRange(-100.0, 100.0);
    ypInput_->setValue(0.0);
    ypInput_->setSingleStep(0.1);
    icLayout->addWidget(ypLabel);
    icLayout->addWidget(ypInput_);

    // Zp input
    QLabel* zpLabel = new QLabel("Z₀", leftPanel_);
    zpInput_ = new QDoubleSpinBox(leftPanel_);
    zpInput_->setRange(-100.0, 100.0);
    zpInput_->setValue(0.0);
    zpInput_->setSingleStep(0.1);
    icLayout->addWidget(zpLabel);
    icLayout->addWidget(zpInput_);

    // Reset button
    resetToDefaultBtn_ = new QPushButton("Reset to Default", leftPanel_);
    connect(resetToDefaultBtn_, &QPushButton::clicked, this, [this]() {
        xpInput_->setValue(0.1);
        ypInput_->setValue(0.0);
        zpInput_->setValue(0.0);
        state_ = { xpInput_->value(), ypInput_->value(), zpInput_->value() };
        resetState();
        update();
    });
    icLayout->addWidget(resetToDefaultBtn_);

    layout->addWidget(icGroup);

    // HELP section
    QGroupBox* helpGroup = new QGroupBox("HELP", leftPanel_);
    QVBoxLayout* helpLayout = new QVBoxLayout(helpGroup);
    helpLayout->setContentsMargins(5, 15, 5, 5);

    QPushButton* helpBtn = new QPushButton("Show Keyboard Shortcuts", leftPanel_);
    connect(helpBtn, &QPushButton::clicked, this, [this]() {
        HelpDialog dlg(this);
        dlg.exec();
    });
    helpLayout->addWidget(helpBtn);

    layout->addWidget(helpGroup);
    layout->addStretch();
}

void MainWindow::createRightPanel() {
    rightPanel_ = new QWidget(this);
    rightPanel_->setMaximumWidth(240);
    rightPanel_->setMinimumWidth(220);
    rightPanel_->setStyleSheet(
        "QWidget { background-color: rgb(35, 35, 45); color: #ecf0f1; }"
        "QLabel { color: #ecf0f1; font-size: 10px; }"
        "QGroupBox { color: #3498db; font-weight: bold; border: 1px solid rgb(60, 60, 70); border-radius: 4px; margin-top: 8px; padding-top: 8px; }"
        "QGroupBox::title { subcontrol-origin: margin; subcontrol-position: top left; padding: 0 3px; }"
        "QComboBox { background-color: rgb(50, 50, 60); color: #ecf0f1; border: 1px solid rgb(70, 70, 80); padding: 4px; }"
        "QSpinBox { background-color: rgb(50, 50, 60); color: #ecf0f1; border: 1px solid rgb(70, 70, 80); padding: 2px; }"
        "QDoubleSpinBox { background-color: rgb(50, 50, 60); color: #ecf0f1; border: 1px solid rgb(70, 70, 80); padding: 2px; }"
        "QCheckBox { color: #ecf0f1; }"
        "QPushButton { background-color: rgb(52, 152, 219); color: white; border: none; padding: 6px; border-radius: 3px; font-weight: bold; font-size: 9px; }"
        "QPushButton:hover { background-color: rgb(41, 128, 185); }"
        "QPushButton:checked { background-color: rgb(46, 204, 113); }"
    );

    QVBoxLayout* layout = new QVBoxLayout(rightPanel_);
    layout->setContentsMargins(10, 10, 10, 10);
    layout->setSpacing(8);

    // VISUALIZATION section
    QGroupBox* vizGroup = new QGroupBox("VISUALIZATION", rightPanel_);
    QVBoxLayout* vizLayout = new QVBoxLayout(vizGroup);
    vizLayout->setContentsMargins(5, 15, 5, 5);
    vizLayout->setSpacing(8);

    // Trail Color
    QLabel* trailColorLabel = new QLabel("Trail Color", rightPanel_);
    trailColorCombo_ = new QComboBox(rightPanel_);
    trailColorCombo_->addItem("By Speed");
    trailColorCombo_->addItem("By Time");
    connect(trailColorCombo_, QOverload<int>::of(&QComboBox::currentIndexChanged), this, [this](int index) {
        colorMode_ = index;
        update();
    });
    vizLayout->addWidget(trailColorLabel);
    vizLayout->addWidget(trailColorCombo_);

    // Trail Length
    QLabel* trailLengthLabel = new QLabel("Trail Length", rightPanel_);
    trailLengthSpinBox_ = new QSpinBox(rightPanel_);
    trailLengthSpinBox_->setRange(100, 10000);
    trailLengthSpinBox_->setValue(5000);
    trailLengthSpinBox_->setSingleStep(500);
    connect(trailLengthSpinBox_, QOverload<int>::of(&QSpinBox::valueChanged), this, [this](int val) {
        maxTrail_ = val;
    });
    vizLayout->addWidget(trailLengthLabel);
    vizLayout->addWidget(trailLengthSpinBox_);

    // Show Grid
    showGridCheckbox_ = new QCheckBox("Show Grid", rightPanel_);
    showGridCheckbox_->setChecked(true);
    connect(showGridCheckbox_, &QCheckBox::toggled, this, [this](bool checked) {
        gridEnabled_ = checked;
        update();
    });
    vizLayout->addWidget(showGridCheckbox_);

    // Poincaré Section
    poincareCheckbox_ = new QCheckBox("Poincaré Section", rightPanel_);
    poincareCheckbox_->setChecked(false);
    connect(poincareCheckbox_, &QCheckBox::toggled, this, [this](bool checked) {
        if (checked) {
            drawMode_ = DrawMode::Both;
        } else {
            drawMode_ = DrawMode::Trail;
        }
        update();
    });
    vizLayout->addWidget(poincareCheckbox_);

    // Section Plane
    QLabel* planelabel = new QLabel("Section Plane (Z =)", rightPanel_);
    sectionPlaneSpinBox_ = new QDoubleSpinBox(rightPanel_);
    sectionPlaneSpinBox_->setRange(-100.0, 100.0);
    sectionPlaneSpinBox_->setValue(0.0);
    sectionPlaneSpinBox_->setSingleStep(1.0);
    connect(sectionPlaneSpinBox_, QOverload<double>::of(&QDoubleSpinBox::valueChanged), this, [this](double val) {
        poincarePlane_ = val;
    });
    vizLayout->addWidget(planelabel);
    vizLayout->addWidget(sectionPlaneSpinBox_);

    layout->addWidget(vizGroup);

    // OVERLAY MODE section
    QGroupBox* overlayGroup = new QGroupBox("OVERLAY MODE", rightPanel_);
    QVBoxLayout* overlayLayout = new QVBoxLayout(overlayGroup);
    overlayLayout->setContentsMargins(5, 15, 5, 5);
    overlayLayout->setSpacing(4);

    const QString overlayNames[] = {"None", "Phase Space", "Energy Graph", "Lyapunov", "Info & Equations"};
    const OverlayMode overlayModes[] = {OverlayMode::None, OverlayMode::PhaseSpace, OverlayMode::Energy, OverlayMode::Lyapunov, OverlayMode::Info};

    for (int i = 0; i < 5; ++i) {
        overlayButtons_[i] = new QPushButton(overlayNames[i], rightPanel_);
        overlayButtons_[i]->setCheckable(true);
        overlayButtons_[i]->setMaximumHeight(24);

        connect(overlayButtons_[i], &QPushButton::toggled, this, [this, i, overlayModes](bool checked) {
            if (checked) {
                overlayMode_ = overlayModes[i];
                // Uncheck other buttons
                for (int j = 0; j < 5; ++j) {
                    if (j != i) overlayButtons_[j]->setChecked(false);
                }
            } else {
                if (overlayMode_ == overlayModes[i]) {
                    overlayMode_ = OverlayMode::None;
                }
            }
            update();
        });

        overlayLayout->addWidget(overlayButtons_[i]);
    }

    layout->addWidget(overlayGroup);

    // STATUS section
    QGroupBox* statusGroup = new QGroupBox("STATUS", rightPanel_);
    QVBoxLayout* statusLayout = new QVBoxLayout(statusGroup);
    statusLayout->setContentsMargins(5, 15, 5, 5);
    statusLayout->setSpacing(4);

    fpsLabel_ = new QLabel("FPS: 60", rightPanel_);
    fpsLabel_->setStyleSheet("color: #2ecc71; font-weight: bold;");
    statusLayout->addWidget(fpsLabel_);

    pointsLabel_ = new QLabel("Points: 0", rightPanel_);
    statusLayout->addWidget(pointsLabel_);

    statusLabel_ = new QLabel("System: Lorenz\nRunning", rightPanel_);
    statusLayout->addWidget(statusLabel_);

    layout->addWidget(statusGroup);
    layout->addStretch();
}

void MainWindow::updateFPS() {
    fpsLabel_->setText(QString("FPS: %1").arg(static_cast<int>(fps_)));
    pointsLabel_->setText(QString("Points: %1").arg(trail_.size()));
    
    QString systemInfo = QString("System: %1\n%2")
        .arg(systemName_)
        .arg(simulationActive_ ? "Running" : "Paused");
    statusLabel_->setText(systemInfo);
}

void MainWindow::resetState() {
    trail_.clear();
    poincarePoints_.clear();
    if (dims_ == 3) {
        state_ = { 0.0, 1.0, 20.0 };
        Vec tmp = state_;
        double sumz = 0.0;
        const int warmSteps = 1000;
        for (int i = 0; i < warmSteps; ++i) {
            rk4_step(system_, tmp, dt_);
            sumz += tmp[2];
        }
        poincarePlane_ = sumz / double(warmSteps);
        sectionPlaneSpinBox_->setValue(poincarePlane_);
    } else if (dims_ == 2) {
        state_ = { 1.0, 0.0 };
    } else if (dims_ == 4) {
        state_ = { M_PI/2.0, 0.0, M_PI/2.0 + 0.01, 0.0 };
    }
}

void MainWindow::step() {
    if (!simulationActive_) return;

    Vec prev = state_;
    rk4_step(system_, state_, dt_);

    for (double v : state_) {
        if (!std::isfinite(v)) {
            resetState();
            return;
        }
    }

    QPointF p = project(state_);
    if (std::isfinite(p.x()) && std::isfinite(p.y())) {
        trail_.push_back(p);
        if (trail_.size() > maxTrail_) trail_.pop_front();
    }

    // Poincare section (only for 3D systems)
    if (dims_ == 3 && (drawMode_ == DrawMode::Poincare || drawMode_ == DrawMode::Both)) {
        for (auto& c : poincarePoints_) {
            c.age++;
        }
        while (!poincarePoints_.empty() && poincarePoints_.front().age > 300) {
            poincarePoints_.pop_front();
        }

        double prevZ = prev[2];
        double newZ  = state_[2];

        // Use configured/autoestimated Poincare plane
        double plane = poincarePlane_;
        bool upwardCross   = (prevZ < plane && newZ >= plane);
        bool downwardCross = (prevZ > plane && newZ <= plane);

        if (upwardCross || (poincareBothDirections_ && downwardCross)) {
            QPointF secPt(center_.x() + state_[0] * scale_,
                          center_.y() - state_[1] * scale_);

            // Store crossing with direction
            poincarePoints_.emplace_back(secPt, upwardCross);

            // Limit buffer size
            if (poincarePoints_.size() > 2000) {
                poincarePoints_.pop_front();
            }
        }
    }

    if (overlayMode_ == OverlayMode::Energy && dims_ == 4) {
        updateEnergy();
    }
    if (overlayMode_ == OverlayMode::Lyapunov) {
        if (!lyapunovInitialized_) initLyapunov();
        updateLyapunov();
    }

    frameCounter_++;
}

QPointF MainWindow::project(const Vec& x) {
    if (dims_ == 3) {
        return QPointF(center_.x() + x[0] * scale_, center_.y() - x[1] * scale_);
    } else if (dims_ == 2) {
        return QPointF(center_.x() + x[0] * scale_, center_.y() - x[1] * scale_);
    } else if (dims_ == 4) {
        double L1 = 1.0, L2 = 1.0;
        double th1 = state_[0], th2 = state_[2];
        double x1 = L1 * std::sin(th1);
        double y1 = -L1 * std::cos(th1);
        double x2 = x1 + L2 * std::sin(th2);
        double y2 = y1 - L2 * std::cos(th2);
        return QPointF(center_.x() + x2 * scale_, center_.y() + y2 * scale_);
    }
    return center_;
}

void MainWindow::paintEvent(QPaintEvent* event) {
    // Let parent handle background and widget rendering
    QMainWindow::paintEvent(event);
    
    // Now draw on the canvas widget area
    if (!canvasWidget_) return;

    QPainter p(this);
    
    // Calculate canvas widget area (accounting for left and right panels)
    int canvasLeft = leftPanel_->width();
    int canvasTop = 0;
    int canvasWidth = canvasWidget_->width();
    int canvasHeight = canvasWidget_->height();

    // Update center relative to canvas
    center_ = QPointF(canvasLeft + canvasWidth / 2.0, canvasTop + canvasHeight / 2.0);

    // Fill canvas background
    p.fillRect(canvasLeft, canvasTop, canvasWidth, canvasHeight, QColor(18, 18, 22));
    p.setRenderHint(QPainter::Antialiasing, true);

    // Draw grid
    if (gridEnabled_) {
        p.setPen(QPen(QColor(60, 60, 70), 1));
        for (int x = canvasLeft; x < canvasLeft + canvasWidth; x += 50) {
            p.drawLine(x, canvasTop, x, canvasTop + canvasHeight);
        }
        for (int y = canvasTop; y < canvasTop + canvasHeight; y += 50) {
            p.drawLine(canvasLeft, y, canvasLeft + canvasWidth, y);
        }
    }

    // Trail rendering
    if ((drawMode_ == DrawMode::Trail || drawMode_ == DrawMode::Both) && trail_.size() > 1) {
        for (int i = 1; i < trail_.size(); ++i) {
            double t = double(i) / trail_.size();
            QColor c;
            if (colorMode_ == 1) { // speed coloring
                double dx = trail_[i].x() - trail_[i-1].x();
                double dy = trail_[i].y() - trail_[i-1].y();
                double speed = std::sqrt(dx*dx + dy*dy);
                double s = std::min(speed / 10.0, 1.0);
                c = QColor::fromHsvF(0.3 + 0.7*s, 1.0, 1.0, fadingEnabled_ ? (0.2 + 0.8*(1.0 - t)) : 1.0);
            } else { // time gradient
                c = QColor::fromHsvF(t, 1.0, 1.0, fadingEnabled_ ? (0.2 + 0.8*(1.0 - t)) : 1.0);
            }
            p.setPen(QPen(c, 2));
            p.drawLine(trail_[i-1], trail_[i]);
        }
    }

    // Poincare section points
    if (drawMode_ == DrawMode::Poincare || drawMode_ == DrawMode::Both) {
        for (const auto& crossing : poincarePoints_) {
            QColor col = crossing.upward ? QColor("#00aaff") : QColor("#ffffff");
            int alpha = static_cast<int>(255 * std::exp(-crossing.age * 0.005));
            col.setAlpha(alpha);

            p.setPen(Qt::NoPen);
            p.setBrush(col);
            p.drawEllipse(crossing.pos, 3, 3);

            QColor halo = col;
            halo.setAlpha(alpha / 3);
            p.setBrush(halo);
            p.drawEllipse(crossing.pos, 6, 6);
        }
    }

    // Educational overlays
    switch (overlayMode_) {
    case OverlayMode::None:      break;
    case OverlayMode::PhaseSpace: drawPhaseSpace(p);     break;
    case OverlayMode::Energy:     if (dims_ == 4) drawEnergyOverlay(p); break;
    case OverlayMode::Lyapunov:   drawLyapunovOverlay(p); break;
    case OverlayMode::Info:       drawInfoOverlay(p);     break;
    }

    // Draw formula SVG
    QString formulaPath;
    if (systemName_ == "Lorenz") {
        formulaPath = ":/images/images/lorenzEquationVector.svg";
    } else if (systemName_ == "Rössler") {
        formulaPath = ":/images/images/RosslerEquationVector.svg";
    } else if (systemName_ == "Van der Pol") {
        formulaPath = ":/images/images/VanDerPolEquationVector.svg";
    } else if (systemName_ == "Double Pendulum") {
        formulaPath = ":/images/images/DoublePendulumEquationVector.svg";
    }

    if (!formulaPath.isEmpty()) {
        QSvgRenderer renderer(formulaPath);
        QSizeF svgSize = renderer.defaultSize();
        if (svgSize.isEmpty()) svgSize = QSizeF(240, 140);

        double scaleFactor = 1.0;
        QSizeF targetSize;
        QRectF fullRect;
        QColor bgColor;
        QRectF renderRect;

        if (systemName_ == "Double Pendulum") {
            double maxWidth = canvasWidth * 0.70;
            if (svgSize.width() > maxWidth) {
                scaleFactor = maxWidth / svgSize.width();
            }
            targetSize = QSizeF(svgSize.width() * scaleFactor, svgSize.height() * scaleFactor);
            fullRect = QRectF(canvasLeft + canvasWidth - targetSize.width() - 30,
                             canvasTop + canvasHeight - targetSize.height() - 30,
                             targetSize.width(), targetSize.height());
            fullRect = fullRect.adjusted(-10, -10, 10, 10);
            bgColor = QColor(30, 30, 40, 90);
            renderRect = QRectF(10, 10, targetSize.width(), targetSize.height());
        } else {
            double maxWidth = canvasWidth * 0.15;
            if (svgSize.width() > maxWidth) {
                scaleFactor = maxWidth / svgSize.width();
            }
            targetSize = QSizeF(svgSize.width() * scaleFactor, svgSize.height() * scaleFactor);
            fullRect = QRectF(canvasLeft + canvasWidth - targetSize.width() - 20,
                             canvasTop + canvasHeight - targetSize.height() - 20,
                             targetSize.width(), targetSize.height());
            fullRect = fullRect.adjusted(-8, -8, 8, 8);
            bgColor = QColor(30, 30, 40, 200);
            renderRect = QRectF(8, 8, targetSize.width(), targetSize.height());
        }

        if (formulaNeedsUpdate_) {
            formulaPixmap_ = QPixmap(fullRect.size().toSize());
            formulaPixmap_.fill(Qt::transparent);
            QPainter pixPainter(&formulaPixmap_);
            pixPainter.fillRect(formulaPixmap_.rect(), bgColor);
            pixPainter.setPen(QPen(QColor(200, 200, 210), 1));
            pixPainter.drawRect(formulaPixmap_.rect().adjusted(1, 1, -1, -1));
            renderer.render(&pixPainter, renderRect);
            formulaNeedsUpdate_ = false;
        }

        p.drawPixmap(fullRect.topLeft(), formulaPixmap_);
    }

    if (!simulationStarted_) {
        p.setFont(QFont("Monospace", 14, QFont::Bold));
        p.setPen(Qt::yellow);
        p.drawText(QRect(canvasLeft, canvasTop, canvasWidth, canvasHeight), Qt::AlignCenter,
                   "Select a system from the left panel to start");
    } else if (!simulationActive_) {
        QRect box(canvasLeft + canvasWidth / 2 - 60, canvasTop + 50, 120, 30);
        p.setBrush(Qt::red);
        p.setPen(Qt::NoPen);
        p.drawRect(box);
        p.setPen(Qt::white);
        p.setFont(QFont("Monospace", 10, QFont::Bold));
        p.drawText(box, Qt::AlignCenter, "PAUSED");
    }
}


void MainWindow::saveSimulationImage(const QString& filename) {
    int canvasLeft = leftPanel_->width();
    int canvasWidth = canvasWidget_->width();
    int canvasHeight = canvasWidget_->height();
    
    QPixmap pixmap(canvasWidth, canvasHeight);
    pixmap.fill(QColor(18, 18, 22));

    QPainter p(&pixmap);
    p.setRenderHint(QPainter::Antialiasing, true);

    p.setPen(QPen(QColor(60, 60, 70), 1));
    for (int x = 0; x < canvasWidth; x += 50) p.drawLine(x, 0, x, canvasHeight);
    for (int y = 0; y < canvasHeight; y += 50) p.drawLine(0, y, canvasWidth, y);

    // Trail (always draw trail in saved image)
    if (trail_.size() > 1) {
        for (int i = 1; i < trail_.size(); ++i) {
            double t = double(i) / trail_.size();
            QColor c;
            if (colorMode_ == 1) {
                double dx = trail_[i].x() - trail_[i-1].x();
                double dy = trail_[i].y() - trail_[i-1].y();
                double speed = std::sqrt(dx*dx + dy*dy);
                double s = std::min(speed / 10.0, 1.0);
                c = QColor::fromHsvF(0.3 + 0.7*s, 1.0, 1.0, fadingEnabled_ ? (0.2 + 0.8*(1.0 - t)) : 1.0);
            } else {
                c = QColor::fromHsvF(t, 1.0, 1.0, fadingEnabled_ ? (0.2 + 0.8*(1.0 - t)) : 1.0);
            }
            p.setPen(QPen(c, 2));
            // Adjust coordinates to be relative to canvas
            QPointF a = trail_[i-1];
            QPointF b = trail_[i];
            a.setX(a.x() - canvasLeft);
            b.setX(b.x() - canvasLeft);
            p.drawLine(a, b);
        }
    }

    // Poincare points if mode includes them
    if (drawMode_ == DrawMode::Poincare || drawMode_ == DrawMode::Both) {
        p.setPen(QPen(QColor("#ffff00"), 8));
        for (const auto& pt : poincarePoints_) {
            QPointF pos = pt.pos;
            pos.setX(pos.x() - canvasLeft);
            p.drawPoint(pos);
        }
    }

    pixmap.save(filename);
}

void MainWindow::setSystem(int id) {
    switch (id) {
    case 1:
        system_ = lorenz();
        dims_ = 3;
        scale_ = 8.0;
        systemName_ = "Lorenz";
        poincareEnabled_ = true;
        break;
    case 2:
        system_ = rossler();
        dims_ = 3;
        scale_ = 30.0;
        systemName_ = "Rössler";
        poincareEnabled_ = true;
        break;
    case 3:
        system_ = van_der_pol(5.0);
        dims_ = 2;
        scale_ = 80.0;
        systemName_ = "Van der Pol";
        poincareEnabled_ = false;
        break;
    case 4:
        system_ = double_pendulum();
        dims_ = 4;
        scale_ = 120.0;
        systemName_ = "Double Pendulum";
        poincareEnabled_ = false;
        break;
    default:
        system_ = lorenz();
        dims_ = 3;
        scale_ = 8.0;
        systemName_ = "Lorenz";
        poincareEnabled_ = true;
        break;
    }

    // Reset overlays
    energyHistory_.clear();
    lyapunovDist_.clear();
    lyapunovInitialized_ = false;

    // Default physical params for double pendulum
    m1_ = 1.0;
    m2_ = 1.0;
    L1_ = 1.0;
    L2_ = 1.0;
    g_ = 9.81;

    formulaNeedsUpdate_ = true;

    resetState();

}

void MainWindow::drawPhaseSpace(QPainter& p) {
    int canvasLeft = leftPanel_->width();
    int canvasTop = 0;
    int canvasWidth = canvasWidget_->width();
    int canvasHeight = canvasWidget_->height();
    
    QRectF inset(canvasLeft + canvasWidth - 300, canvasTop + 50, 250, 250);
    p.fillRect(inset, QColor(30, 30, 40));
    p.setPen(QPen(QColor(200, 200, 210), 1));
    p.drawRect(inset);

    p.setFont(QFont("Monospace", 9));
    p.drawText(inset.left() + 8, inset.top() + 18, "Phase space");

    if (trail_.size() < 2) return;

    double minX = std::numeric_limits<double>::max();
    double maxX = std::numeric_limits<double>::lowest();
    double minY = std::numeric_limits<double>::max();
    double maxY = std::numeric_limits<double>::lowest();

    for (const QPointF& pt : trail_) {
        minX = std::min(minX, pt.x());
        maxX = std::max(maxX, pt.x());
        minY = std::min(minY, pt.y());
        maxY = std::max(maxY, pt.y());
    }

    double rangeX = maxX - minX;
    double rangeY = maxY - minY;
    if (rangeX < 1e-6) rangeX = 1.0;
    if (rangeY < 1e-6) rangeY = 1.0;

    double sx = inset.width() / rangeX;
    double sy = inset.height() / rangeY;
    double s = std::min(sx, sy) * 0.9;

    p.setPen(QPen(QColor(120, 120, 130), 1, Qt::DashLine));
    p.drawLine(inset.left(), inset.center().y(), inset.right(), inset.center().y());
    p.drawLine(inset.center().x(), inset.top(), inset.center().x(), inset.bottom());

    p.setFont(QFont("Monospace", 8));
    if (dims_ == 4) {
        p.drawText(inset.right() - 20, inset.center().y() - 5, "θ1");
        p.drawText(inset.center().x() + 5, inset.top() + 15, "θ2");
    } else {
        p.drawText(inset.right() - 15, inset.center().y() - 5, "x");
        p.drawText(inset.center().x() + 5, inset.top() + 15, "y");
    }

    p.setPen(QPen(QColor("#ffaa00"), 1));
    for (int i = 1; i < trail_.size(); ++i) {
        QPointF a(inset.left() + (trail_[i-1].x() - canvasLeft - minX) * s,
                  inset.bottom() - (trail_[i-1].y() - minY) * s);
        QPointF b(inset.left() + (trail_[i].x() - canvasLeft - minX) * s,
                  inset.bottom() - (trail_[i].y() - minY) * s);
        p.drawLine(a, b);
    }
}

void MainWindow::updateEnergy() {
    double th1 = state_[0], w1 = state_[1];
    double th2 = state_[2], w2 = state_[3];

    double x1 = L1_ * std::sin(th1);
    double y1 = -L1_ * std::cos(th1);
    double x2 = x1 + L2_ * std::sin(th2);
    double y2 = y1 - L2_ * std::cos(th2);

    double vx1 = L1_ * w1 * std::cos(th1);
    double vy1 = L1_ * w1 * std::sin(th1);
    double vx2 = vx1 + L2_ * w2 * std::cos(th2);
    double vy2 = vy1 + L2_ * w2 * std::sin(th2);

    double KE = 0.5 * m1_ * (vx1*vx1 + vy1*vy1) + 0.5 * m2_ * (vx2*vx2 + vy2*vy2);
    double PE = m1_ * g_ * (y1) + m2_ * g_ * (y2);

    double E = KE + PE;
    energyHistory_.push_back(E);
    if (energyHistory_.size() > energyHistoryMax_) energyHistory_.pop_front();
}

void MainWindow::initLyapunov() {
    state2_ = state_;
    if (!state2_.empty()) state2_[0] += 1e-6;
    lyapunovDist_.clear();
    lyapunovInitialized_ = true;
}

void MainWindow::updateLyapunov() {
    rk4_step(system_, state2_, dt_);

    double d = 0.0;
    int n = std::min<int>(state_.size(), state2_.size());
    for (int i = 0; i < n; ++i) {
        double di = state_[i] - state2_[i];
        d += di * di;
    }
    d = std::sqrt(d);

    lyapunovDist_.push_back(d);
    if (lyapunovDist_.size() > lyapunovHistoryMax_) lyapunovDist_.pop_front();
}

void MainWindow::setInitialConditions() {
    InitialConditionsDialog dlg(systemName_, this);
    if (dlg.exec() == QDialog::Accepted) {
        std::vector<double> vals = dlg.values();

        // Ensure the provided vector matches the expected dimensionality
        if (vals.size() != static_cast<size_t>(dims_)) {
            vals.resize(dims_, 0.0);
        }

        state_ = vals;
        trail_.clear();
        poincarePoints_.clear();

        simulationStarted_ = true;
        simulationActive_ = true;
        update();
    }
}

void MainWindow::keyPressEvent(QKeyEvent* e) {
    switch (e->key()) {
    case Qt::Key_1:
        setSystem(1);
        systemsList_->setCurrentRow(0);
        simulationStarted_ = true;
        simulationActive_ = true;
        break;
    case Qt::Key_2:
        setSystem(2);
        systemsList_->setCurrentRow(1);
        simulationStarted_ = true;
        simulationActive_ = true;
        break;
    case Qt::Key_3:
        setSystem(3);
        systemsList_->setCurrentRow(2);
        simulationStarted_ = true;
        simulationActive_ = true;
        break;
    case Qt::Key_4:
        setSystem(4);
        systemsList_->setCurrentRow(3);
        simulationStarted_ = true;
        simulationActive_ = true;
        break;
    case Qt::Key_R:
        resetState();
        simulationStarted_ = true;
        simulationActive_ = true;
        break;

    case Qt::Key_Plus:
    case Qt::Key_Equal: scale_ *= 1.1; break;
    case Qt::Key_Minus: scale_ /= 1.1; break;

    case Qt::Key_BracketLeft:
        dt_ = std::max(0.001, dt_ / 1.2);
        break;
    case Qt::Key_BracketRight:
        dt_ = std::min(0.05, dt_ * 1.2);
        break;

    case Qt::Key_C: colorMode_ = 1 - colorMode_; break;
    case Qt::Key_F: fadingEnabled_ = !fadingEnabled_; break;
    case Qt::Key_G: gridEnabled_ = !gridEnabled_; break;

    case Qt::Key_O:
        if (drawMode_ == DrawMode::Trail) drawMode_ = DrawMode::Poincare;
        else if (drawMode_ == DrawMode::Poincare) drawMode_ = DrawMode::Both;
        else drawMode_ = DrawMode::Trail;
        break;

    case Qt::Key_T: maxTrail_ += 1000; break;
    case Qt::Key_Y: if (maxTrail_ > 1000) maxTrail_ -= 1000; break;

    case Qt::Key_H:
        if (overlayMode_ == OverlayMode::None) overlayMode_ = OverlayMode::PhaseSpace;
        else if (overlayMode_ == OverlayMode::PhaseSpace) overlayMode_ = OverlayMode::Energy;
        else if (overlayMode_ == OverlayMode::Energy) overlayMode_ = OverlayMode::Lyapunov;
        else if (overlayMode_ == OverlayMode::Lyapunov) overlayMode_ = OverlayMode::Info;
        else overlayMode_ = OverlayMode::None;
        break;
    case Qt::Key_I:
        setInitialConditions();
        break;
    case Qt::Key_Space:
        if (simulationStarted_) {
            simulationActive_ = !simulationActive_;
        }
        break;
    default: QMainWindow::keyPressEvent(e); break;
    }

    update();
}

void MainWindow::resizeEvent(QResizeEvent* event) {
    QMainWindow::resizeEvent(event);
    formulaNeedsUpdate_ = true;
}
